# Real time app using socket.io
### Developing basic app to allow user to add comments and everyone else can see it on real time.

- Download the code. 

- Run `npm install` to install dependencies.

- Visit `localhost:3000` to view the app.

- Tutorial link : http://codeforgeek.com/2015/03/real-time-app-socket-io/
